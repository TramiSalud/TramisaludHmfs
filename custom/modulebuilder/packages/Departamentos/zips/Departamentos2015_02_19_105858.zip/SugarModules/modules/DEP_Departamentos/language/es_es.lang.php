<?php 
 // created: 2015-02-19 10:58:58
$mod_strings['LNK_NEW_RECORD'] = 'Crear Departamentos';
$mod_strings['LNK_LIST'] = 'Vista Departamentos';
$mod_strings['LNK_IMPORT_DEP_DEPARTAMENTOS'] = 'Importar Departamentos';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Departamentos Lista';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Buscar Departamentos';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'Mi Departamentos';

?>
