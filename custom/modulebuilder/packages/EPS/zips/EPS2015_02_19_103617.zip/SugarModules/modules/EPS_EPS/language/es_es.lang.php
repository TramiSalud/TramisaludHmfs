<?php 
 // created: 2015-02-19 10:36:17
$mod_strings['LBL_DEPARTAMENTO'] = 'Departamento';
$mod_strings['LBL_DIGITOVERIFICACION'] = 'Digito Verificacion';
$mod_strings['LBL_EMAILANEXO9'] = 'Email Anexo 9';

?>
