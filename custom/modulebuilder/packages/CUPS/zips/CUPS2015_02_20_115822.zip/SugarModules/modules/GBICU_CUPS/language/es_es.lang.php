<?php 
 // created: 2015-02-20 11:58:22
$mod_strings['LBL_DESCRIPTION'] = 'Descripción';
$mod_strings['LBL_NOMBRESERVMP'] = 'Nombre Servicio Para MP';
$mod_strings['LBL_CODIGOISS_ISS_ISS_ID'] = 'Código ISS Fail (related  ID)';
$mod_strings['LBL_CODIGOISS'] = 'Código ISS Fail';
$mod_strings['LBL_CODIGOSOAT_GBISO_SOAT_ID'] = 'Código SOAT Fail (related  ID)';
$mod_strings['LBL_CODIGOSOAT'] = 'Código SOAT Fail';
$mod_strings['LBL_CODISS'] = 'Código ISS';
$mod_strings['LBL_CODSOAT'] = 'Código SOAT';
$mod_strings['LBL_CODMP'] = 'Código MP';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Homologador ISS';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Homologador SOAT';
$mod_strings['LBL_EDITVIEW_PANEL4'] = 'Homologador MP';
$mod_strings['LBL_EDITVIEW_PANEL5'] = 'Nuevo Panel 5';
$mod_strings['LBL_EDITVIEW_PANEL6'] = 'Nuevo Panel 6';
$mod_strings['LBL_EDITVIEW_PANEL7'] = 'Nuevo Panel 7';
$mod_strings['LBL_GBI_GRUPO'] = 'Grupo';
$mod_strings['LBL_GBI_SUBBRUPO'] = 'Sub_Grupo';

?>
