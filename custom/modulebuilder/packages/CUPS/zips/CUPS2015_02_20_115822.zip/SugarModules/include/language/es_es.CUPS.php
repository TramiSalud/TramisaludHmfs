<?php 
$app_list_strings['gbi_subbrupo_list'] = array (
  '' => '',
  'Ortopedia' => 'Ortopedia',
  'Urologia' => 'Urología',
);$app_list_strings['gbi_grupo_list'] = array (
  '' => '',
  'AydaDX' => 'Ayuda DX',
  'Consulta' => 'Consulta',
  'Cirugia' => 'Cirugía ',
  'Procedmtos' => 'Procedimientos',
  'Internacion' => 'Internación',
  'Insumo' => 'Insumo',
  'AAIU' => 'AIU',
  'PyP' => 'P Y P',
  'Remision' => 'Remisión',
);