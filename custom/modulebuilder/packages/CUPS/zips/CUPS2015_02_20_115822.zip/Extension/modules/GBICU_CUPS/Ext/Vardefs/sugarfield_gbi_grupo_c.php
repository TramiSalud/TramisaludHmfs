<?php
 // created: 2014-05-13 15:16:50
$dictionary['GBICU_CUPS']['fields']['gbi_grupo_c']['labelValue']='Grupo';

 ?>