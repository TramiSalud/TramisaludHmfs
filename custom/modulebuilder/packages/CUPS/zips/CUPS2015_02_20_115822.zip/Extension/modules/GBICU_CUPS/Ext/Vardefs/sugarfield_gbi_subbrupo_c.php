<?php
 // created: 2014-04-14 17:10:34
$dictionary['GBICU_CUPS']['fields']['gbi_subbrupo_c']['labelValue']='Sub_Grupo';

 ?>