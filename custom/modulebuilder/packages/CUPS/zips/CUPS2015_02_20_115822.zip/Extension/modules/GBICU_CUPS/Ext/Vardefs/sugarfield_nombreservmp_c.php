<?php
 // created: 2014-04-09 15:58:55
$dictionary['GBICU_CUPS']['fields']['nombreservmp_c']['labelValue']='Nombre Servicio Para MP';

 ?>