<?php
 // created: 2014-04-04 11:41:13
$dictionary['gbiA4_Anexo4']['fields']['nombquienautoriza_c']['labelValue']='Nombre de quien autoriza';

 ?>