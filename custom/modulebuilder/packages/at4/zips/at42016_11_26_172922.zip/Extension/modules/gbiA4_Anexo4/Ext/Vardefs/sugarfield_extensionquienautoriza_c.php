<?php
 // created: 2014-04-04 11:51:05
$dictionary['gbiA4_Anexo4']['fields']['extensionquienautoriza_c']['labelValue']='Extensión';

 ?>