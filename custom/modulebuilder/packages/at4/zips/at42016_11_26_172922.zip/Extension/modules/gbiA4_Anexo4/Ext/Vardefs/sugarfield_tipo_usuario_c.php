<?php
 // created: 2016-01-23 11:40:12
$dictionary['gbiA4_Anexo4']['fields']['tipo_usuario_c']['labelValue']='Tipo de usuario';

 ?>