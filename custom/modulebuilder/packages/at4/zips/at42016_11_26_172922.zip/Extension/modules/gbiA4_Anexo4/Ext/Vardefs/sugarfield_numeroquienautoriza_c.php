<?php
 // created: 2014-04-04 12:26:52
$dictionary['gbiA4_Anexo4']['fields']['numeroquienautoriza_c']['labelValue']='Número';

 ?>