<?php
 // created: 2016-01-23 12:19:45
$dictionary['gbiA4_Anexo4']['fields']['descripcion_diagnostico_sec_c']['labelValue']='Descripción diagnóstico secundario';

 ?>