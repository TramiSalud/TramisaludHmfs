<?php
 // created: 2016-01-23 12:17:33
$dictionary['gbiA4_Anexo4']['fields']['diagnostico_adicional_c']['labelValue']='Diagnóstico adicional';

 ?>