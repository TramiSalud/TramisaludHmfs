<?php
 // created: 2016-01-23 12:21:53
$dictionary['gbiA4_Anexo4']['fields']['descripcion_diagnostico_ad_c']['labelValue']='Descripción diagnóstico adicional';

 ?>