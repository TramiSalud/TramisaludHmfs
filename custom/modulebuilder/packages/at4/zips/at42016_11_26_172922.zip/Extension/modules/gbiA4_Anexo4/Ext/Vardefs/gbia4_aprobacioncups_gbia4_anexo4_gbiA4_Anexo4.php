<?php
// created: 2014-03-21 17:31:02
$dictionary["gbiA4_Anexo4"]["fields"]["gbia4_aprobacioncups_gbia4_anexo4"] = array (
  'name' => 'gbia4_aprobacioncups_gbia4_anexo4',
  'type' => 'link',
  'relationship' => 'gbia4_aprobacioncups_gbia4_anexo4',
  'source' => 'non-db',
  'module' => 'gbiA4_Aprobacioncups',
  'bean_name' => 'gbiA4_Aprobacioncups',
  'side' => 'right',
  'vname' => 'LBL_GBIA4_APROBACIONCUPS_GBIA4_ANEXO4_FROM_GBIA4_APROBACIONCUPS_TITLE',
);
