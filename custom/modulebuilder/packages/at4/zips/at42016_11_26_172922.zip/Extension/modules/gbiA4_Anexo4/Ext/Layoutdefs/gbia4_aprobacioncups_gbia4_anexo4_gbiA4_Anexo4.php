<?php
 // created: 2014-03-21 17:31:02
$layout_defs["gbiA4_Anexo4"]["subpanel_setup"]['gbia4_aprobacioncups_gbia4_anexo4'] = array (
  'order' => 100,
  'module' => 'gbiA4_Aprobacioncups',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'Carga Cups',
  'get_subpanel_data' => 'gbia4_aprobacioncups_gbia4_anexo4',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
