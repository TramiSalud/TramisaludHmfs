<?php
 // created: 2016-01-12 13:06:47
$dictionary['gbiA4_Anexo4']['fields']['ubicacion_paciente_c']['labelValue']='Ubicacion del paciente';

 ?>