<?php
 // created: 2014-07-03 09:23:41
$dictionary['gbiA4_Anexo4']['fields']['fecha_recibida_c']['options']='date_range_search_dom';
$dictionary['gbiA4_Anexo4']['fields']['fecha_recibida_c']['labelValue']='Fecha Recibida';
$dictionary['gbiA4_Anexo4']['fields']['fecha_recibida_c']['enable_range_search']='1';

 ?>