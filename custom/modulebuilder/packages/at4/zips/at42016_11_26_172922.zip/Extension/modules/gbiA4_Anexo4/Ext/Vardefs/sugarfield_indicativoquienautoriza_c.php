<?php
 // created: 2014-04-04 11:49:37
$dictionary['gbiA4_Anexo4']['fields']['indicativoquienautoriza_c']['labelValue']='Indicativo';

 ?>