<?php

$dictionary["gbiA4_Anexo4"]["fields"]["diagnostico_principal_c"]["populate_list"] = array(
		"name","id","description"
);

$dictionary["gbiA4_Anexo4"]["fields"]["diagnostico_principal_c"]["field_list"] = array(
		"diagnostico_principal_c","cie_cie10_id_c","descripcion_diagnostico_pp_c"
);

?>