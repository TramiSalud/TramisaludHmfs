<?php
 // created: 2016-01-23 12:05:55
$dictionary['gbiA4_Anexo4']['fields']['diagnostico_principal_c']['labelValue']='Diagnóstico principal';

 ?>