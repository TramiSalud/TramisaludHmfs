<?php

$dictionary["gbiA4_Anexo4"]["fields"]["diagnostico_secundario_c"]["populate_list"] = array(
		"name","id","description"
);

$dictionary["gbiA4_Anexo4"]["fields"]["diagnostico_secundario_c"]["field_list"] = array(
		"diagnostico_secundario_c","cie_cie10_id1_c","descripcion_diagnostico_sec_c"
);

?>
