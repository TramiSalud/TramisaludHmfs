<?php
 // created: 2016-01-23 12:06:45
$dictionary['gbiA4_Anexo4']['fields']['descripcion_diagnostico_pp_c']['labelValue']='Descripción diagnóstico principal';

 ?>