<?php
 // created: 2014-04-04 11:46:42
$dictionary['gbiA4_Anexo4']['fields']['cargoquienautoriza_c']['labelValue']='Cargo o actividad';

 ?>