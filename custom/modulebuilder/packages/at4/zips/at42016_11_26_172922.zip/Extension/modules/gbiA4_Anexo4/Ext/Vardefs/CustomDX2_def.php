<?php

$dictionary["gbiA4_Anexo4"]["fields"]["diagnostico_adicional_c"]["populate_list"] = array(
		"name","id","description"
);

$dictionary["gbiA4_Anexo4"]["fields"]["diagnostico_adicional_c"]["field_list"] = array(
		"diagnostico_adicional_c","cie_cie10_id2_c","descripcion_diagnostico_ad_c"
);

?>