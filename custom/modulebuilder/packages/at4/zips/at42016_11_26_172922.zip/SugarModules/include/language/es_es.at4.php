<?php 
$app_list_strings['concepto_list'] = array (
  '' => '',
  'Cuota' => 'Cuota Moderadora',
  'copago' => 'Copago',
  'cuota_recuperacion' => 'Cuota de Recuperación',
  'otro' => 'Otro',
);$app_list_strings['ubicacion_paciente_list'] = array (
  'Urgencias' => 'Urgencias',
  'Hospitalizacion' => 'Hospitalización',
  'Consulta_Externa' => 'Consulta Externa',
  '' => '',
);$app_list_strings['tipo_usuario_list'] = array (
  'Interno' => 'Interno',
  'Externo' => 'Externo',
);