<?php 
$app_list_strings['concepto_list'] = array (
  'Cuota' => 'Cuota ¨Moderadora',
  'copago' => 'Copago',
  'cuota_recuperacion' => 'Cuota de Recuperación',
  'otro' => 'Otro',
  '' => '',
);