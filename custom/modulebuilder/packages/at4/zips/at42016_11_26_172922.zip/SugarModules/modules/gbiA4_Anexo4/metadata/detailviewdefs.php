<?php
$module_name = 'gbiA4_Anexo4';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          2 => 'DELETE',
          4 => 
          array (
            'customCode' => '<input title="GenerarPDF" type="submit" name="button" value="Generar PDF Anexo 4" onClick="window.open(\'index.php?module=gbiA4_Anexo4&action=GenerarPdf&record={$fields.id.value}\')";>',
            'name' => 'GenerarPDF',
            'label' => 'Generar PDF',
          ),
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL4' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL3' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'fecha_recibida_c',
            'label' => 'LBL_FECHA_RECIBIDA',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'gbian_anexo2_gbia4_anexo4_1_name',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'gbia4_anexo4_gbia3_anexo3_name',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'date_entered',
            'comment' => 'Date record created',
            'label' => 'LBL_DATE_ENTERED',
          ),
          1 => 
          array (
            'name' => 'date_modified',
            'comment' => 'Date record last modified',
            'label' => 'LBL_DATE_MODIFIED',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'created_by_name',
            'label' => 'LBL_CREATED',
          ),
          1 => 
          array (
            'name' => 'modified_by_name',
            'label' => 'LBL_MODIFIED_NAME',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'accounts_gbia4_anexo4_1_name',
          ),
        ),
      ),
      'lbl_editview_panel4' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'prestador_servicio',
            'studio' => 'visible',
            'label' => 'LBL_PRESTADOR_SERVICIO',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'porcentaje_servicio',
            'label' => 'LBL_PORCENTAJE_SERVICIO',
          ),
          1 => 
          array (
            'name' => 'semanas_afiliacion',
            'label' => 'LBL_SEMANAS_AFILIACION',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'reclamo_tiquete',
            'label' => 'LBL_RECLAMO_TIQUETE',
          ),
        ),
      ),
      'lbl_editview_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'concepto',
            'studio' => 'visible',
            'label' => 'LBL_CONCEPTO',
          ),
          1 => 
          array (
            'name' => 'valor_pesos',
            'label' => 'LBL_VALOR_PESOS',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'porcentaje',
            'label' => 'LBL_PORCENTAJE',
          ),
          1 => 
          array (
            'name' => 'maximo_valor',
            'label' => 'LBL_MAXIMO_VALOR',
          ),
        ),
      ),
      'lbl_editview_panel3' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'nombquienautoriza_c',
            'label' => 'LBL_NOMBQUIENAUTORIZA',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'indicativoquienautoriza_c',
            'label' => 'LBL_INDICATIVOQUIENAUTORIZA',
          ),
          1 => 
          array (
            'name' => 'cargoquienautoriza_c',
            'label' => 'LBL_CARGOQUIENAUTORIZA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'numeroquienautoriza_c',
            'label' => 'LBL_NUMEROQUIENAUTORIZA',
          ),
          1 => 
          array (
            'name' => 'celquienautoriza_c',
            'label' => 'LBL_CELQUIENAUTORIZA',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'extensionquienautoriza_c',
            'label' => 'LBL_EXTENSIONQUIENAUTORIZA',
          ),
        ),
      ),
    ),
  ),
);
?>
