<?php

require_once ('include/MVC/Controller/SugarController.php');

class gbiA4_Anexo4Controller extends SugarController{

	public function action_GenerarPdf(){
	
		$this->view = 'pdf';
	
	}
	

}

?>