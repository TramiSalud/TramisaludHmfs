<?php 
 // created: 2016-11-26 17:29:19
$mod_strings['LBL_CONCEPTO'] = 'Concepto';
$mod_strings['LBL_GBIA4_APROBACIONCUPS_GBIA4_ANEXO4_FROM_GBIA4_APROBACIONCUPS_TITLE'] = 'Aprobación de Cups';
$mod_strings['LBL_NOMBQUIENAUTORIZA'] = 'Nombre de quien autoriza';
$mod_strings['LBL_CARGOQUIENAUTORIZA'] = 'Cargo o actividad';
$mod_strings['LBL_INDICATIVOQUIENAUTORIZA'] = 'Indicativo';
$mod_strings['LBL_EXTENSIONQUIENAUTORIZA'] = 'Extensión';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Información de Quien Autoriza';
$mod_strings['LBL_NAME'] = 'Nro. de Autorización';
$mod_strings['LBL_NUMEROQUIENAUTORIZA'] = 'Número';
$mod_strings['LBL_CELQUIENAUTORIZA'] = 'Teléfono celular';
$mod_strings['LBL_EDITVIEW_PANEL4'] = 'Información del Prestador (Autorizado)';
$mod_strings['LBL_RECLAMO_TIQUETE'] = 'Reclamo de Tiquete, Bono o Vale de Pago';
$mod_strings['LBL_SEMANAS_AFILIACION'] = 'Semanas de Afiliación del Paciente';
$mod_strings['LBL_PRESTADOR_SERVICIO_IPS_IPS_ID'] = 'Prestador (related  ID)';
$mod_strings['LBL_PRESTADOR_SERVICIO'] = 'Prestador';
$mod_strings['LBL_PORCENTAJE_SERVICIO'] = 'Porcentaje del Valor del Servicio Autorizado a Pagar por la Entidad Responsable';
$mod_strings['LBL_GBIA4_ANEXO4_GBIA3_ANEXO3_FROM_GBIA3_ANEXO3_TITLE'] = 'Anexo 3';
$mod_strings['LBL_FECHA_RECIBIDA'] = 'Fecha Recibida';
$mod_strings['LBL_UBICACION_PACIENTE'] = 'Ubicacion del paciente';
$mod_strings['LBL_TIPO_USUARIO'] = 'Tipo de usuario';
$mod_strings['LBL_DIAGNOSTICO_PRINCIPAL_CIE_CIE10_ID'] = 'Diagnóstico principal (related  ID)';
$mod_strings['LBL_DIAGNOSTICO_PRINCIPAL'] = 'Diagnóstico principal';
$mod_strings['LBL_DESCRIPCION_DIAGNOSTICO_PP'] = 'Descripción diagnóstico principal';
$mod_strings['LBL_DIAGNOSTICO_SECUNDARIO_CIE_CIE10_ID'] = 'Diagnóstico secundario (related  ID)';
$mod_strings['LBL_DIAGNOSTICO_SECUNDARIO'] = 'Diagnóstico secundario';
$mod_strings['LBL_DIAGNOSTICO_ADICIONAL_CIE_CIE10_ID'] = 'Diagnóstico adicional (related  ID)';
$mod_strings['LBL_DIAGNOSTICO_ADICIONAL'] = 'Diagnóstico adicional';
$mod_strings['LBL_DESCRIPCION_DIAGNOSTICO_SEC'] = 'Descripción diagnóstico secundario';
$mod_strings['LBL_DESCRIPCION_DIAGNOSTICO_AD'] = 'Descripción diagnóstico adicional';
$mod_strings['LBL_EDITVIEW_PANEL5'] = 'Diagnóstico';
$mod_strings['LNK_NEW_RECORD'] = 'Crear Anexo 4';
$mod_strings['LNK_LIST'] = 'Vista Anexo 4';
$mod_strings['LNK_IMPORT_GBIA4_ANEXO4'] = 'Importar Anexo 4';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Anexo 4 Lista';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Buscar Anexo 4';
$mod_strings['LBL_GBIAN_ANEXO2_GBIA4_ANEXO4_1_FROM_GBIAN_ANEXO2_TITLE'] = 'Anexo 2';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'Mi Anexo 4';

?>
