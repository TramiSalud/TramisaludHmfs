<?php
 // created: 2014-07-10 15:09:59
$dictionary['gbi_Anexo9']['fields']['marcado_enviar_c']['labelValue']='Marcado Para Enviar';

 ?>