<?php
 // created: 2014-08-11 16:43:01
$dictionary['gbi_Anexo9']['fields']['codigo_diagnostico_3_c']['labelValue']='Código de Diagnóstico 3';

 ?>