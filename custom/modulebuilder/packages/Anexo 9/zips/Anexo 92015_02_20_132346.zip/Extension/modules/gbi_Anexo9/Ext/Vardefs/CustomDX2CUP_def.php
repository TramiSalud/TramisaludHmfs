<?php

$dictionary["gbi_Anexo9"]["fields"]["cups3_c"]["populate_list"] = array(
		"name","id","description"
);

$dictionary["gbi_Anexo9"]["fields"]["cups3_c"]["field_list"] = array(
		"cups3_c","gbicu_cups_id2_c","dxcups3_c"
);

?>