<?php
 // created: 2014-08-11 16:44:30
$dictionary['gbi_Anexo9']['fields']['dxcups_c']['labelValue']='Descripción de CUPS';

 ?>