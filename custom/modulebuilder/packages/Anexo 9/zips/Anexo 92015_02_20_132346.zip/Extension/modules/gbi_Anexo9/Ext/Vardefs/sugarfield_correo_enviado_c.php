<?php
 // created: 2014-07-10 15:09:33
$dictionary['gbi_Anexo9']['fields']['correo_enviado_c']['labelValue']='Correo Enviado';

 ?>