<?php
 // created: 2014-08-20 17:05:13
$dictionary['gbi_Anexo9']['fields']['codigo_diagnostico_c']['labelValue']='Código Diagnóstico';

 ?>