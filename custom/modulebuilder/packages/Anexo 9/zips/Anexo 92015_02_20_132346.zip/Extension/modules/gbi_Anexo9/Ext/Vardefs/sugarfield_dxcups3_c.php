<?php
 // created: 2014-08-11 16:46:42
$dictionary['gbi_Anexo9']['fields']['dxcups3_c']['labelValue']='Descripción de CUPS 3';

 ?>