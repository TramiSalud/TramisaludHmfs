<?php
$dictionary["gbi_Anexo9"]["fields"]["eps"]["populate_list"] = array(
		"name","id", 'emailanexo9_c'
);

$dictionary["gbi_Anexo9"]["fields"]["eps"]["field_list"] = array(
		"eps","eps_eps_id_c","correo_envio_c"
);
?>
