<?php
 // created: 2014-08-11 16:45:48
$dictionary['gbi_Anexo9']['fields']['dxcups2_c']['labelValue']='Descripción de CUPS 2';

 ?>