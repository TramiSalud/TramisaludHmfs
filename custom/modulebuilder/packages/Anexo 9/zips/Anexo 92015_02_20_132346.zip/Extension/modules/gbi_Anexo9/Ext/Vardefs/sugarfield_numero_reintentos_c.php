<?php
 // created: 2014-07-10 15:08:50
$dictionary['gbi_Anexo9']['fields']['numero_reintentos_c']['labelValue']='Número Reintentos';

 ?>