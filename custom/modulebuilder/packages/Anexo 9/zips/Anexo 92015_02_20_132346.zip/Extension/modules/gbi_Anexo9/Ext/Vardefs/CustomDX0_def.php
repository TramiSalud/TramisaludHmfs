<?php

$dictionary["gbi_Anexo9"]["fields"]["codigo_diagnostico_c"]["populate_list"] = array(
		"name","id","description"
);

$dictionary["gbi_Anexo9"]["fields"]["codigo_diagnostico_c"]["field_list"] = array(
		"codigo_diagnostico_c","cie_cie10_id_c","dxcodigodiagnostico_c"
);

?>