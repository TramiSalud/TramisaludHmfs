<?php
 // created: 2014-08-11 16:40:33
$dictionary['gbi_Anexo9']['fields']['cups3_c']['labelValue']='CUPS 3';

 ?>