<?php
 // created: 2014-08-11 16:39:17
$dictionary['gbi_Anexo9']['fields']['cups2_c']['labelValue']='CUPS 2';

 ?>