<?php

$dictionary["gbi_Anexo9"]["fields"]["especialista"]["populate_list"] = array(
		"name","id","nombres","apellidos","cargo","telppal","extension","telcel"
);

$dictionary["gbi_Anexo9"]["fields"]["especialista"]["field_list"] = array(
		"especialista","esp_especialista_id_c","nombreespecialistaso","apellidoespecialistaso","cargoactividad","telefonoespecialista","extensionsolicitante","celularsolicitante"
);

?>