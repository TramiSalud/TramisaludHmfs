<?php
 // created: 2014-10-23 10:09:42
$dictionary['gbi_Anexo9']['fields']['cama_c']['labelValue']='Cama';

 ?>