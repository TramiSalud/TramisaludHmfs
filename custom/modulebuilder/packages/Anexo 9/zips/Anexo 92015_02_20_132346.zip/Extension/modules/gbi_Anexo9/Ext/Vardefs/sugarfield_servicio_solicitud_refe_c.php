<?php
 // created: 2014-10-02 06:44:15
$dictionary['gbi_Anexo9']['fields']['servicio_solicitud_refe_c']['labelValue']='Servicio por el cual solicita la referencia';

 ?>