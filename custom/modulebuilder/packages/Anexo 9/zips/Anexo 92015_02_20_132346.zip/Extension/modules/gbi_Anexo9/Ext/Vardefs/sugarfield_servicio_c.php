<?php
 // created: 2014-10-02 06:57:46
$dictionary['gbi_Anexo9']['fields']['servicio_c']['labelValue']='Servicio';

 ?>