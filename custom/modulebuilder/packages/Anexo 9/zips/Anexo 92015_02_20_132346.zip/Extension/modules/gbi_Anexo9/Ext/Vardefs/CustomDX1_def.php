<?php

$dictionary["gbi_Anexo9"]["fields"]["codigo_de_diagnostico_2_c"]["populate_list"] = array(
		"name","id","description"
);

$dictionary["gbi_Anexo9"]["fields"]["codigo_de_diagnostico_2_c"]["field_list"] = array(
		"codigo_de_diagnostico_2_c","cie_cie10_id1_c","dxcodigodignostico2_c"
);

?>