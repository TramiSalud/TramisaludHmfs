<?php
 // created: 2014-07-10 15:10:59
$dictionary['gbi_Anexo9']['fields']['rebotado_c']['labelValue']='Rebotado';

 ?>