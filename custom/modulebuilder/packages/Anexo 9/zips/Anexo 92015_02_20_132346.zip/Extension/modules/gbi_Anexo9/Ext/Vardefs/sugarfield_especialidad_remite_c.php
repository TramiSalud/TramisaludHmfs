<?php
 // created: 2014-10-02 07:05:14
$dictionary['gbi_Anexo9']['fields']['especialidad_remite_c']['labelValue']='Especialidad que remite';

 ?>