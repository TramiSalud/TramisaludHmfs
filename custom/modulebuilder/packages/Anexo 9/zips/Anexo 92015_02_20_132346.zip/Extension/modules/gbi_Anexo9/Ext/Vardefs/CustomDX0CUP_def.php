<?php

$dictionary["gbi_Anexo9"]["fields"]["servicio_soli_refe"]["populate_list"] = array(
		"name","id","description"
);

$dictionary["gbi_Anexo9"]["fields"]["servicio_soli_refe"]["field_list"] = array(
		"servicio_soli_refe","gbicu_cups_id_c","dxcups_c"
);

?>