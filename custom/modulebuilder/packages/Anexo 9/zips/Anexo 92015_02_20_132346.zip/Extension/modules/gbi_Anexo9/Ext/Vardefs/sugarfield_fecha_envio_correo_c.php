<?php
 // created: 2014-07-10 15:08:05
$dictionary['gbi_Anexo9']['fields']['fecha_envio_correo_c']['options']='date_range_search_dom';
$dictionary['gbi_Anexo9']['fields']['fecha_envio_correo_c']['labelValue']='Fecha Envío de Correo';
$dictionary['gbi_Anexo9']['fields']['fecha_envio_correo_c']['enable_range_search']='1';

 ?>