<?php
 // created: 2014-08-11 16:53:16
$dictionary['gbi_Anexo9']['fields']['dxcodigodignostico2_c']['labelValue']='Descripción de Código Diagnóstico 2';

 ?>