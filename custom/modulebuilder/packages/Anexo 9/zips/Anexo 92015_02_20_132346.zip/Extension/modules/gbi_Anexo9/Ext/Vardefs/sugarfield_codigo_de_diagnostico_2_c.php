<?php
 // created: 2014-08-11 16:41:28
$dictionary['gbi_Anexo9']['fields']['codigo_de_diagnostico_2_c']['labelValue']='Código de Diagnóstico 2';

 ?>