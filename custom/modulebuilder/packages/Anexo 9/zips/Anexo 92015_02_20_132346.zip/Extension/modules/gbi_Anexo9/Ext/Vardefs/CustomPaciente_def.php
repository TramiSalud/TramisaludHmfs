<?php

$dictionary["gbi_Anexo9"]["fields"]["accounts_gbi_anexo9_1_name"]["populate_list"] = array(
		"name","id","primernombre_c","segundonombre_c","primerapellido_c","segundoapellido_c","celular_c","email1"
);

$dictionary["gbi_Anexo9"]["fields"]["accounts_gbi_anexo9_1_name"]["field_list"] = array(
		"accounts_gbi_anexo9_1_name","accounts_gbi_anexo9_1accounts_ida","primernombre","segundonombre","primerapellido","segundoapellido","celular","correoemail"
);

?>