<?php

$dictionary["gbi_Anexo9"]["fields"]["codigo_diagnostico_3_c"]["populate_list"] = array(
		"name","id","description"
);

$dictionary["gbi_Anexo9"]["fields"]["codigo_diagnostico_3_c"]["field_list"] = array(
		"codigo_diagnostico_3_c","cie_cie10_id2_c","dxcodigodiagnostico3_c"
);

?>