<?php

$dictionary["gbi_Anexo9"]["fields"]["cups2_c"]["populate_list"] = array(
		"name","id","description"
);

$dictionary["gbi_Anexo9"]["fields"]["cups2_c"]["field_list"] = array(
		"cups2_c","gbicu_cups_id1_c","dxcups2_c"
);

?>