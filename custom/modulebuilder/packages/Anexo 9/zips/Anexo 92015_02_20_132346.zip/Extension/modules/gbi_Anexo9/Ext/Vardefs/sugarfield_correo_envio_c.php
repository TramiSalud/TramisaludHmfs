<?php
 // created: 2014-10-27 21:54:33
$dictionary['gbi_Anexo9']['fields']['correo_envio_c']['labelValue']='Correo de envio (informativo)';

 ?>