<?php 
$app_list_strings['estado_1'] = array (
  'pendiente' => 'Pendiente',
  'cerrado' => 'Cerrado',
  '' => '',
);