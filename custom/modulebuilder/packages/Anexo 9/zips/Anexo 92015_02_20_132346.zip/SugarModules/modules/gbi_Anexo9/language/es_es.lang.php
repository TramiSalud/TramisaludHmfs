<?php 
 // created: 2015-02-20 13:23:45
$mod_strings['LBL_FECHA_ENVIO_CORREO'] = 'Fecha Envío de Correo';
$mod_strings['LBL_NUMERO_REINTENTOS'] = 'Número Reintentos';
$mod_strings['LBL_CORREO_ENVIADO'] = 'Correo Enviado';
$mod_strings['LBL_MARCADO_ENVIAR'] = 'Marcado Para Enviar';
$mod_strings['LBL_REBOTADO'] = 'Rebotado';
$mod_strings['LBL_GBI_ANEXO9_GBIHI_HISTORIALCORREO_1_FROM_GBIHI_HISTORIALCORREO_TITLE'] = 'Historial Envío';
$mod_strings['LBL_CAMA_C'] = 'Cama';
$mod_strings['LBL_SERVICIO_C'] = 'Servicio';
$mod_strings['LBL_CODIGO_DIAGNOSTICO_C_CIE_CIE10_ID'] = 'Código Diagnóstico  (related  ID)';
$mod_strings['LBL_CODIGO_DIAGNOSTICO_C'] = 'Código Diagnóstico';
$mod_strings['LBL_EDITVIEW_PANEL8'] = 'Ubicación del paciente';
$mod_strings['LBL_DETAILVIEW_PANEL8'] = 'Otra Información';
$mod_strings['LBL_QUICKCREATE_PANEL8'] = 'Otra Informacion';
$mod_strings['LBL_CUPS2_GBICU_CUPS_ID'] = 'CUPS 2 (related  ID)';
$mod_strings['LBL_CUPS2'] = 'CUPS 2';
$mod_strings['LBL_CUPS3_GBICU_CUPS_ID'] = 'CUPS 3 (related  ID)';
$mod_strings['LBL_CUPS3'] = 'CUPS 3';
$mod_strings['LBL_CODIGO_DE_DIAGNOSTICO_2_CIE_CIE10_ID'] = 'Código de Diagnóstico 2 (related  ID)';
$mod_strings['LBL_CODIGO_DE_DIAGNOSTICO_2'] = 'Código de Diagnóstico 2';
$mod_strings['LBL_CODIGO_DIAGNOSTICO_3_CIE_CIE10_ID'] = 'Código de Diagnóstico 3 (related  ID)';
$mod_strings['LBL_CODIGO_DIAGNOSTICO_3'] = 'Código de Diagnóstico 3';
$mod_strings['LBL_DXCUPS'] = 'Descripción de CUPS';
$mod_strings['LBL_DXCUPS2'] = 'Descripción de CUPS 2';
$mod_strings['LBL_DXCUPS3'] = 'Descripción de CUPS 3';
$mod_strings['LBL_DXCODIGODIAGNOSTICO3'] = 'Descripción de Código  Diagnostico 3';
$mod_strings['LBL_DXCODIGODIAGNOSTICO'] = 'Descripción de Código Diagnóstico';
$mod_strings['LBL_DXCODIGODIGNOSTICO2'] = 'Descripción de Código Diagnóstico 2';
$mod_strings['LBL_SERVICIO'] = 'Servicio';
$mod_strings['LBL_CODIGO_DIAGNOSTICO'] = 'Código Diagnóstico';
$mod_strings['LBL_CAMA'] = 'Cama';
$mod_strings['LBL_SERVICIO_SOLICITUD_REFE'] = 'Servicio por el cual solicita la referencia';
$mod_strings['LBL_SERVICIO_SOLI_REFE_GBICU_CUPS_ID'] = 'CUPS 1 (related  ID)';
$mod_strings['LBL_SERVICIO_SOLI_REFE'] = 'CUPS 1';
$mod_strings['LBL_ESPECIALIDAD_REMITE'] = 'Especialidad que remite';
$mod_strings['LBL_CORREO_ENVIO'] = 'Correo de envio (informativo)';
$mod_strings['LBL_GBI_ANEXO9_GBI_EGRESO_CENTRO_REGULADOR_1_FROM_GBI_EGRESO_CENTRO_REGULADOR_TITLE'] = 'Egreso Centro Regulador Hospitalario';

?>
