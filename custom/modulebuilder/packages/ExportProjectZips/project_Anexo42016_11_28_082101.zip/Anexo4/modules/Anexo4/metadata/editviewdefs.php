<?php
$module_name = 'gbiA4_Anexo4';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'date_entered',
            'comment' => 'Date record created',
            'label' => 'LBL_DATE_ENTERED',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'porcentaje_servicio',
            'label' => 'LBL_PORCENTAJE_SERVICIO',
          ),
          1 => 
          array (
            'name' => 'semanas_afiliacion',
            'label' => 'LBL_SEMANAS_AFILIACION',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'reclamo_tiquete',
            'label' => 'LBL_RECLAMO_TIQUETE',
          ),
        ),
      ),
      'lbl_editview_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'concepto',
            'studio' => 'visible',
            'label' => 'LBL_CONCEPTO',
          ),
          1 => 
          array (
            'name' => 'valor_pesos',
            'label' => 'LBL_VALOR_PESOS',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'porcentaje',
            'label' => 'LBL_PORCENTAJE',
          ),
          1 => 
          array (
            'name' => 'maximo_valor',
            'label' => 'LBL_MAXIMO_VALOR',
          ),
        ),
      ),
    ),
  ),
);
?>
