<?php
$module_name = 'gbiA4_Anexo4';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'gbia4_anexo4_gbia3_anexo3_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_GBIA4_ANEXO4_GBIA3_ANEXO3_FROM_GBIA3_ANEXO3_TITLE',
        'id' => 'GBIA4_ANEXO4_GBIA3_ANEXO3GBIA3_ANEXO3_IDA',
        'width' => '10%',
        'default' => true,
        'name' => 'gbia4_anexo4_gbia3_anexo3_name',
      ),
    ),
    'advanced_search' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'default' => true,
        'width' => '10%',
      ),
      'gbia4_anexo4_gbia3_anexo3_name' => 
      array (
        'type' => 'relate',
        'link' => true,
        'label' => 'LBL_GBIA4_ANEXO4_GBIA3_ANEXO3_FROM_GBIA3_ANEXO3_TITLE',
        'width' => '10%',
        'default' => true,
        'id' => 'GBIA4_ANEXO4_GBIA3_ANEXO3GBIA3_ANEXO3_IDA',
        'name' => 'gbia4_anexo4_gbia3_anexo3_name',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
