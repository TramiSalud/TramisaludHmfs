<?php
$module_name = 'gbiA4_Anexo4';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'GBIA4_ANEXO4_GBIA3_ANEXO3_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_GBIA4_ANEXO4_GBIA3_ANEXO3_FROM_GBIA3_ANEXO3_TITLE',
    'id' => 'GBIA4_ANEXO4_GBIA3_ANEXO3GBIA3_ANEXO3_IDA',
    'width' => '10%',
    'default' => true,
  ),
);
?>
