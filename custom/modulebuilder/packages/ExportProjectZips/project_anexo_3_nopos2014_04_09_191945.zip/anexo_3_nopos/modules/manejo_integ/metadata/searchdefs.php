<?php
$module_name = 'GBIA3_manejo_integ';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'cantidadcups' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CANTIDADCUPS',
        'width' => '10%',
        'default' => true,
        'name' => 'cantidadcups',
      ),
    ),
    'advanced_search' => 
    array (
      'cantidadcups' => 
      array (
        'type' => 'varchar',
        'label' => 'LBL_CANTIDADCUPS',
        'width' => '10%',
        'default' => true,
        'name' => 'cantidadcups',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'maxColumnsBasic' => '4',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
