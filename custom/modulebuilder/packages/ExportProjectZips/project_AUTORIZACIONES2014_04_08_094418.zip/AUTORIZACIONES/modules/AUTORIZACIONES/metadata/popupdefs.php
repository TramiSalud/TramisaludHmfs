<?php
$popupMeta = array (
    'moduleMain' => 'GBI_AUTORIZACIONES',
    'varName' => 'GBI_AUTORIZACIONES',
    'orderBy' => 'gbi_autorizaciones.name',
    'whereClauses' => array (
  'name' => 'gbi_autorizaciones.name',
),
    'searchInputs' => array (
  0 => 'gbi_autorizaciones_number',
  1 => 'name',
  2 => 'priority',
  3 => 'status',
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
),
);
