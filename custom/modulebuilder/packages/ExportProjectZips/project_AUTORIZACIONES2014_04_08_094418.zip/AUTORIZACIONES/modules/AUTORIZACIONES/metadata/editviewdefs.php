<?php
$module_name = 'GBI_AUTORIZACIONES';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL2' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'entidad',
            'label' => 'LBL_ENTIDAD',
          ),
          1 => 'assigned_user_name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'factura',
            'label' => 'LBL_FACTURA',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'fecha_solicitud',
            'label' => 'LBL_FECHA_SOLICITUD',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'fecha_autorizacion',
            'label' => 'LBL_FECHA_AUTORIZACION',
          ),
        ),
        4 => 
        array (
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'tipo_hospitalizacion',
            'studio' => 'visible',
            'label' => 'LBL_TIPO_HOSPITALIZACION',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'dias_uci',
            'label' => 'LBL_DIAS_UCI',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'diagnostico',
            'label' => 'LBL_DIAGNOSTICO',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'dias_habitacion',
            'label' => 'LBL_DIAS_HABITACION',
          ),
        ),
        9 => 
        array (
          0 => 
          array (
            'name' => 'gbi_autorizaciones_accounts_name',
          ),
        ),
      ),
      'lbl_editview_panel2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'valor_aut_estancia',
            'label' => 'LBL_VALOR_AUT_ESTANCIA',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'valor_aut_honorarios',
            'label' => 'LBL_VALOR_AUT_HONORARIOS',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'valor_aut_miscelaneos',
            'label' => 'LBL_VALOR_AUT_MISCELANEOS',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'valor_anestesia',
            'label' => 'LBL_VALOR_ANESTESIA',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'valor_total',
            'label' => 'LBL_VALOR_TOTAL',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'copago',
            'label' => 'LBL_COPAGO',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'valor_factura',
            'label' => 'LBL_VALOR_FACTURA',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'compromiso_ingreso',
            'label' => 'LBL_COMPROMISO_INGRESO',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'compromiso_egreso',
            'label' => 'LBL_COMPROMISO_EGRESO',
          ),
        ),
        9 => 
        array (
          0 => 
          array (
            'name' => 'autoriza',
            'label' => 'LBL_AUTORIZA',
          ),
        ),
      ),
    ),
  ),
);
?>
