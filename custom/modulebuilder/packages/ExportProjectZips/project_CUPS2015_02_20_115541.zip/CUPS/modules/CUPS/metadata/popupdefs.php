<?php
$popupMeta = array (
    'moduleMain' => 'GBICU_CUPS',
    'varName' => 'GBICU_CUPS',
    'orderBy' => 'gbicu_cups.name',
    'whereClauses' => array (
  'name' => 'gbicu_cups.name',
  'subcategoria' => 'gbicu_cups.subcategoria',
  'estadocups' => 'gbicu_cups.estadocups',
  'assigned_user_name' => 'gbicu_cups.assigned_user_name',
),
    'searchInputs' => array (
  1 => 'name',
  4 => 'subcategoria',
  5 => 'estadocups',
  6 => 'assigned_user_name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'name' => 'name',
  ),
  'subcategoria' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SUBCATEGORIA',
    'width' => '10%',
    'name' => 'subcategoria',
  ),
  'estadocups' => 
  array (
    'type' => 'enum',
    'studio' => 'visible',
    'label' => 'LBL_ESTADOCUPS',
    'width' => '10%',
    'name' => 'estadocups',
  ),
  'assigned_user_name' => 
  array (
    'link' => true,
    'type' => 'relate',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'id' => 'ASSIGNED_USER_ID',
    'width' => '10%',
    'name' => 'assigned_user_name',
  ),
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
  'SUBCATEGORIA' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SUBCATEGORIA',
    'width' => '10%',
    'default' => true,
  ),
  'ESTADOCUPS' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_ESTADOCUPS',
    'width' => '10%',
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'link' => true,
    'type' => 'relate',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'id' => 'ASSIGNED_USER_ID',
    'width' => '10%',
    'default' => true,
  ),
),
);
