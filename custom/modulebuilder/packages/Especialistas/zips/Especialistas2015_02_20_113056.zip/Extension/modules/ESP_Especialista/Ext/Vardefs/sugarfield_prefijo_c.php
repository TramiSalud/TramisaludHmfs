<?php
 // created: 2014-04-07 19:07:44
$dictionary['ESP_Especialista']['fields']['prefijo_c']['labelValue']='Prefijo';

 ?>