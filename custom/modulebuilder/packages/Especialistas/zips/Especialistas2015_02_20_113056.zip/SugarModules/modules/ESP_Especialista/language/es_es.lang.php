<?php 
 // created: 2015-02-20 11:30:55
$mod_strings['LNK_NEW_RECORD'] = 'Crear Especialistas';
$mod_strings['LNK_LIST'] = 'Vista Especialistas';
$mod_strings['LNK_IMPORT_ESP_ESPECIALISTA'] = 'Importar Especialistas';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Especialista Lista';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Buscar Especialista';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'Mi Especialistas';
$mod_strings['LBL_NAME'] = 'Registro Médico';
$mod_strings['LBL_REGISTROMEDICO'] = 'Nro. Documento';
$mod_strings['LBL_PREFIJO'] = 'Prefijo';

?>
