<?php 
 // created: 2015-02-19 10:33:30
$mod_strings['LBL_DEPARTAMENTO'] = 'Departamento';

?>
