<?php
 // created: 2014-04-09 16:07:44
$dictionary['GBICU_CUPS']['fields']['codmp_c']['labelValue']='Código MP';

 ?>