<?php
 // created: 2014-04-09 16:07:00
$dictionary['GBICU_CUPS']['fields']['codsoat_c']['labelValue']='Código SOAT';

 ?>