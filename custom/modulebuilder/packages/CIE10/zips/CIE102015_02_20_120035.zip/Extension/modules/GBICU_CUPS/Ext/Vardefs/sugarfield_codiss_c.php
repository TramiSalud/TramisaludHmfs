<?php
 // created: 2014-04-09 16:05:53
$dictionary['GBICU_CUPS']['fields']['codiss_c']['labelValue']='Código ISS';

 ?>