<?php 
 // created: 2015-02-19 11:01:17
$mod_strings['LBL_DEPARTAMENTO'] = 'Departamento';

?>
