<?php
// created: 2022-06-29 18:56:41
$dictionary["Account"]["fields"]["vd_validacion_derechos_accounts"] = array (
  'name' => 'vd_validacion_derechos_accounts',
  'type' => 'link',
  'relationship' => 'vd_validacion_derechos_accounts',
  'source' => 'non-db',
  'module' => 'vd_validacion_derechos',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_VD_VALIDACION_DERECHOS_ACCOUNTS_FROM_VD_VALIDACION_DERECHOS_TITLE',
);
